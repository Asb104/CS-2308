
#include <iostream>
using namespace std;
struct arr
{
int *a1;
int l1;
};
int sum(arr[], int);
int *getOdd(arr[], int);
int main ()
{
int SIZE, total;
cout << " of what length is the array?\n";
cin >> SIZE;

arr Andrew[SIZE];
total=sum(Andrew, SIZE);
cout<< "The total sum is " << total << endl;
int Odds[SIZE];
Andrew->a1=getOdd(Andrew, SIZE);
cout << "Here are the odd numbers\n";
for (int z=0; z<SIZE; z++)
{
if (*(Andrew->a1+z)%2 == 1)
cout << *(Andrew->a1 + z) << endl;
}

return 0;
}

int sum(arr Andrew[],int SIZE)
{
int totalSum,count=0;
for (int i=0; i<SIZE; i++)
{
cout << "Please enter an integer for point " << i+1 << endl;
cin >> Andrew[i].l1;
totalSum=Andrew[i].l1;
count+=totalSum;
}
return count;
}

int *getOdd(arr Andrew[],int SIZE)
{
	int *pointer;
int oddNum[SIZE];
for (int i=0; i<SIZE; i++)
{
cout << "Please enter "<<(SIZE/2)<< " odd integers, then " <<(SIZE/2)<<
       	" even ones. \n"; 
cin >> Andrew[i].l1;
if ((Andrew[i].l1 % 2) == 1)
Andrew[i].l1 = oddNum[i];
else
oddNum[i]=2;
}
pointer = &oddNum[0];
return pointer;
}


