
#include <isotream>
using namespace std;
struct arr
{
int *a1
int l1
};
