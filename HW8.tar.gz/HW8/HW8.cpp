#include<iostream>

#include<iomanip>

#include<cstring>

#include<string>


using namespace std;


// Static member variable type string to translate from integer to month-Date format


// Class declaration

class DayOfYear

{

public:

int Date;

string Month;


// Constructor function

DayOfYear(int Snap)

{

Date = Snap;



} // end constructor function


void print()

{

if(Date >= 1 && Date <= 31)

{

cout <<" Day "<<Date-1<<" would be " <<"January " << Date << endl;

}

if(Date >= 32 && Date <= 59)

{
cout <<" Day "<<Date-1<<" would be " <<"February "<< Date-31 << endl;


}


if(Date >= 60 && Date <= 90)

{
cout <<" Day "<<Date-1<<" would be " <<"March"<< Date-59 << endl;


}


if(Date >= 91 && Date <= 120)

{
cout <<" Day "<<Date-1<<" would be " <<"April"<< Date-90 << endl;


}


if(Date >= 121 && Date <= 151)

{
cout <<" Day "<<Date-1<<" would be " <<"May"<< Date-120 << endl;


}


if(Date >= 152 && Date <= 181)

{
cout <<" Day "<<Date-1<<" would be " <<"June" << Date -151<< endl;


}


if(Date >= 182 && Date <= 212)

{
cout <<" Day "<<Date-1<<" would be " <<"July" << Date-181 << endl;


}


if(Date >= 213 && Date <= 243)

{
cout <<" Day "<<Date-1<<" would be " <<"August" << Date-212 << endl;


}


if(Date >= 244 && Date <= 273)

{
cout <<" Day "<<Date-1<<" would be " <<"September" << Date -243<< endl;


}


if(Date >= 274 && Date <= 304)

{
cout <<" Day "<<Date-1<<" would be " <<"October"<< Date-273 << endl;



}


if(Date >= 305 && Date <= 334)

{
cout <<" Day "<<Date-1<<" would be " <<"November"<< Date-304 << endl;


}


if(Date >= 335 && Date <= 365)

{
cout <<" Day "<<Date-1<<" would be " << "December" << Date -334<< endl;


}


} // end print function


}; // end Class DayOfYear




int main()

{

// How do I get the main function to display the appropriately formatted month Date configuration

// for the Date that the user chooses?

int Snap;

cout << "Please enter a number from 0 to 365" << endl;

cin >> Snap;
Snap++;

DayOfYear instance = DayOfYear (Snap);

instance.print();


cin.ignore();



return 0;


}

