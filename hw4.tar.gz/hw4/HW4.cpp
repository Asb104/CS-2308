# include <iostream>
# include <iomanip>
using namespace std;
void Sort_Array(int[], const int, int);
int Search_Array(int[], const int, int);
 
int main()
{
int tickets[10]={85647, 26791, 26792, 33445, 55555, 62483, 93121, 79422, 13579, 77777};
const int SIZE=10;
int winningNum;
int value;
cout << "Please enter a 5 digit integer that will be the winning lottery number. \n";
cin >> winningNum;
Sort_Array(tickets, SIZE, winningNum);
value = Search_Array(tickets, SIZE, winningNum);
if (value == -1)
	cout <<"I'm sorry, you are not a winner :( Please try again! \n";

else
cout <<   "Congrats on winning the lottery! \n";

return 0;
}

/************************************************************/

void Sort_Array(int tickets[], const int SIZE, int winningNum)  
{
bool flag;
int helper;
	do
	{
	flag=false;
	for (int i =0; i < (SIZE-1); i++)
		{
			if (tickets[i]>tickets[i+1])
				{
					helper=tickets[i];
					tickets[i]=tickets[i+1];
					tickets[i+1]=helper;
					flag=true;
				}
		}
	}
	while (flag);
	
	cout << "Here is my sorted Array: \n";
	cout << "****************************************************\n";

	for (int j=0; j<SIZE; j++)
		cout << setprecision(5) << left << tickets[j] <<endl;

	cout << "****************************************************\n\n\n";
return;
}

/**************************************************************/

int Search_Array(int tickets[], const int SIZE, int winningNum)
{
int start = 0, end = SIZE, value = -1;  //Array positioning and initalizing position
int middle;		//Midpoint of array


		middle= ((start+end)/2)-1;  //for midpoint
		if (tickets[middle] == winningNum)
			{ 
				value=middle;
				return value;
			}	
		else if (tickets[middle] < winningNum)
			start= middle+1;
		else if (tickets[middle] > winningNum)
			end=middle-1;
	
for (int i=start; i<=end; i++)
	{
		if (tickets[i] == winningNum)
			{
				value = i;
				cout << "The Winning Number is... " << tickets[i] <<endl;
				return value;
			}
			
	}

return value;
}
