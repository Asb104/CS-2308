#include <iostream> 
#include <iomanip>

using namespace std;
class DivSales
{
private:

		static double TotalSales;
			double quarter[4];

public:

	double print(int);
	void GetQuarters();
	void displayDivisonTotal();
	void getCompanyTotal();
};

double DivSales::TotalSales = 0;
void DivSales::GetQuarters()
{
	for (int i =0; i<4; i++)
	{
		cout << "The sales for the quarter "<< i+1<< ": ";
            cin>> quarter [i];

            TotalSales += quarter[i];

            while (quarter[i] < 0)
            {
                 cout<< "Error, please enter a positive sale amount: $";
                cin >> quarter [i];
            }
        }
}	
double DivSales::print(int A)
{	return quarter[A];	}


void DivSales::displayDivisonTotal()
{
double counter=0;
for (int i=0; i<4; i++)
{

cout << fixed <<setprecision(2) << right;
	cout <<setw(20)<< "Quarter " << i+1 << ": " <<setw(10)<<quarter[i]<<endl;
	counter=counter+quarter[i];
}
cout << "Divison Total:" << counter<<endl;

return;
}

void DivSales::getCompanyTotal()
{cout  << "The yearly revenue is: " << TotalSales;

	return;}

int main()
{


DivSales divison[6];
for (int i=0; i<6; i++)
{

	divison[i].GetQuarters();
}
for (int j=0; j<6; j++)
{
	cout << fixed <<setprecision(2) << right;
	cout <<setw(30) << "Report for Divison " <<j+1 <<":" <<endl;

	divison[j].displayDivisonTotal();
}   

divison[6].getCompanyTotal();
cout<<endl;
	return 0;
}
