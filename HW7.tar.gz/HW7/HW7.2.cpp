#include <iostream>
#include <iomanip>

using namespace std;
/*Length at least 10, and at most 12.	
- At least 2 lower case, and 2 upper case.	
- At least 3, but not more than	5, digits.	
- No white space.*/

bool PasswordVal(char[]);

int main()
{
bool permitor;
int wordCount=0;
char password[31];
cout << "Please enter your password. \n";
cin.getline(password, 31);
permitor=PasswordVal(password);
while(permitor != true)
{
cout << "Your password is invalid please enter a new password.\n";
cin.getline(password, 31);
permitor=PasswordVal(password);
}
cout << "This pasword is acceptable and validated. \n";
return 0;
}

bool PasswordVal(char password[])
{
bool flag=true;
int lower=0, upper=0, digits=0, length=0, counter=0;

for (int i=0; password[i] != '\0'; i++)
{
	if(isupper(password[i]))
			upper++;
	else if(islower(password[i]))
			lower++;
	else if(isdigit(password[i]))
			digits++;
counter++;
}
if (counter < 10 || counter > 12)
{
cout<< "Your password is to short/long. It must be between 10-12 characters.\n";
flag=false;
}
if (upper<2)
{
cout<< "Your password needs 2 CAPITAL characters.\n";
flag=false;
}
if (lower<2)
{
cout<< "Your password needs 2 lower case characters.\n";
flag=false;
}
if (digits<3||digits>5)
{
cout<< "Your password needs at least 3, but no ";
       cout <<	"more than 5 digit characters.\n";
flag=false;
}


return flag;
}

