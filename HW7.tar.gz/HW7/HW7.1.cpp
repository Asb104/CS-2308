#include <iostream>
#include <iomanip>

using namespace std;
int WordCounter(char*);

int main()
{
int wordCount=0;
char quote[51];
cout << " Enter a string and a word count will be given.";
       cout<<	"(less than 50 characters).\n";
cin.getline(quote,51);
wordCount=WordCounter(quote);
cout << "The string you entered has "<< wordCount << " words in it.\n";
return 0;
}

int WordCounter(char *quote)
{
	int counter=0;
for(int i=0; *(quote+i) != '\0'; i++)
	{
	if(*(quote+i) == ' ')
		counter++;
	}
return counter+1;  //Space after last word not counted
}

