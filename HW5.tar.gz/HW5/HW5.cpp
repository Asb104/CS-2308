#include <iostream>
#include <iomanip>

using namespace std;

struct Rectangle  
{
double length;
double width;
};

void Sort_Array(const int, int *);
int Find_median(const int, int *;

int main()
{
/*****************************************
 * Assigning Array and create Data Set   *
 * **************************************/
double sum_area;	
int num;
cout << "How many numbers would you like for there to be in the Data Set? \n";
cin >> num;
const int SIZE = num;
int Set[SIZE];
/*****************************************
 * Assigning Pointer to the array set   *
 * **************************************/

int *Setptr;
Setptr = Set;
for (int i=0; i<SIZE; i++)
{
cout << "Please enter the Data Set point number " << (i+1) << ".\n";
cin >> Set[i];
}
cout << "Here is your data Set-->";
for (int j=0; j<SIZE; j++)
{	
cout << "["<< *(Setptr + j) << "] ";  //Validating Pointer
}
cout << "\n";
Sort_Array(SIZE, Setptr);

cout << "Here is your sorted data Set (Selection Sort) --> ";
for (int j=0; j<SIZE; j++)
{	
cout << "["<< *(Setptr + j) << "] ";  //Validating Pointer
}
cout << "\n";

return 0;
}

/*********************************
 * Selection Sort of pointers    *
 * ******************************/
void Sort_Array(const int SIZE, int *Setptr)
{
int min, temp;
for ( int i =0; i<SIZE-1; i++)
{
min = i;
	for (int j=i+1; j<SIZE; j++)
	{
	if ( *(Setptr + j) < *(Setptr + min) )
		{
		min = j;
		}
	}
	if (min != i)
	{	
	temp = *(Setptr + i);
	*(Setptr + i)=*(Setptr + min);
	*(Setptr + min) = temp;
	}
}

return;
}

double sumArea(const int SIZE, 
