#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

struct Rectangle  
{
double length;
double width;
};

void Sort_Array(const int, int *);
void Find_median (const int, int *);

int main()
{
/*****************************************
 * Assigning Array and create Data Set   *
 * **************************************/
double sum_area;	
int num;
cout << "How many numbers would you like for there to be in the Data Set? \n";
cin >> num;
while (num <2)
{cout << "invalid must be bigger than 2. \n";
	cin >> num;
}

const int SIZE = num;

int Set[SIZE];
/*****************************************
 * Assigning Pointer to the array set   *
 * **************************************/

int *Setptr;
Setptr = Set;
for (int i=0; i<SIZE; i++)
{
cout << "Please enter the Data Set point number " << (i+1) << ".\n";
cin >> Set[i];
}
cout << "Here is your data Set-->";
for (int j=0; j<SIZE; j++)
{	
cout << "["<< *(Setptr + j) << "] ";  //Validating Pointer
}
cout << "\n";
Sort_Array(SIZE, Setptr);

cout << "Here is your sorted data Set (Selection Sort) --> ";
for (int j=0; j<SIZE; j++)
{	
cout << "["<< *(Setptr + j) << "] ";  //Validating Pointer
}
cout << "\n";

int middle;
Find_median(SIZE, Setptr);
return 0;
}

/*********************************
 * Selection Sort of pointers    *
 * ******************************/
void Sort_Array(const int SIZE, int *Setptr)
{
int min, temp;
for ( int i =0; i<SIZE-1; i++)
{
min = i;
	for (int j=i+1; j<SIZE; j++)
	{
	if ( *(Setptr + j) < *(Setptr + min) )
		{
		min = j;
		}
	}
	if (min != i)
	{	
	temp = *(Setptr + i);
	*(Setptr + i)=*(Setptr + min);
	*(Setptr + min) = temp;
	}
}

return;
}

void Find_median(const int SIZE, int *Setptr)
{	
int middle;
int middle1=0;
int middleAvg=0;
	if (SIZE % 2 == 1)
	{
	middle =  *(Setptr + ((SIZE-1)/2));
	cout << "The median data point is " << middle <<endl;
	}
	else
	{
	middle = *(Setptr + (SIZE/2));
	middle1 = *(Setptr + ((SIZE/2)-1));
	middleAvg=(middle1+middle)/2;

	cout << "The median data point is " << middleAvg <<endl;
	}
return;
}
