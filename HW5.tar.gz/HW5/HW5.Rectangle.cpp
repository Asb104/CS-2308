
#include <iostream>
#include <iomanip>

using namespace std;

struct Rectangle  
{
double length;
double width;
double area;
};

double sumArea(const int);

int main()
{
/*****************************************
 * asking for number of rectangles   *
 * **************************************/
double total;	
int num;
cout << "How many rectangles would you like for there to be? \n";
cin >> num;
const int SIZE = num;
total = sumArea(SIZE);
cout << "The total area of all the rectangles is " << total << " units squared.\n";
return 0;
}

double sumArea (const int SIZE)
{
double totalarea;
Rectangle *Areaptr;
Areaptr = new Rectangle[SIZE];
for (int i=0; i<SIZE; i++)
{
cout << "Please enter Rectangle " << (i+1) << " length.\n";
cin >> Areaptr->length;
cout << "Please enter Rectangle " << (i+1) << " width.\n";
cin >> Areaptr->width;
Areaptr->area=(Areaptr->length*Areaptr->width);
cout << "The area of Rectangle " << (i+1) << " is " << Areaptr->area <<endl;
totalarea+=Areaptr->area;
cout << "The running total area total is " << totalarea <<endl;
}
delete [] Areaptr;
Areaptr = 0;
return totalarea;
}






