#include<iostream>
#include <iomanip>
using namespace std;

template<class T>

class DynamicStack
{
   private:
      struct StackNode
      {
         T value;
         StackNode *next;
      };
      StackNode *top;
   public:
     // Constructor
     DynamicStack( )
     {
        top = NULL;
     }
     // Destructor
     ~DynamicStack();
  
    // Stack operations
    void push(T);
    void pop(T &);
    bool isEmpty();
};
// Destructor
// This function deletes every node in the list.
template<class T>
DynamicStack<T>::~DynamicStack()
{
     StackNode *nodePtr, *nextNode;
      nodePtr = top;
// Traverse the list deleting each node.
while (nodePtr != NULL)
{
    nextNode = nodePtr->next;
   delete nodePtr;
   nodePtr = nextNode;
  }
}
// Member function push the argument to stack
template<class T>
void DynamicStack<T>::push(T num)
{
   StackNode *newNode;
   // Allocate a new node
   newNode = new StackNode;
   newNode->value = num;
// If there are no nodes
if (isEmpty())
{
     top = newNode;
     newNode->next = NULL;
}
else // insert NewNode before top.
{
      newNode->next = top;
      top = newNode;
}
}
// Member function pop pops the value at the top stack
template<class T>
void DynamicStack<T>::pop(T &num)
{
StackNode *temp;
   if (isEmpty())
{
     cout << "The stack is empty.\n";
   }
   else
{
       num = top->value;
       temp = top->next;
       delete top;
      top = temp;
   }
}
// Member function isEmpty returns true
template<class T>
bool DynamicStack<T>::isEmpty()
{
    bool status;
    if (!top)
         status = true;
    else
        status = false;
     return status;
}
// main method

DynamicStack<char> brace_check(string inp)
{
	DynamicStack<char> temp;
	
	for(int i = 0; i < inp.length(); i++)
		if(inp[i] == '(' || ')' || '{' || '}' || '[' || ']')
			temp.push(inp[i]);
		
	return temp;
}



int main( )
{
    	int catchVar;
   string catchStackVar1;
   // Create a DynamicIntStack object.
    DynamicStack<int> stack;
    DynamicStack<string> stack1;
      // Push the values O,L,L,Eand H onto the stack.
     cout << setw(20)<< left<< "Pushing Andrew\n\n";
      stack1.push("Andrew");
      cout << setw(20)<< left << "Pushing Bill\n\n";
      stack1.push("Bill");
     cout << setw(20)<< left << "Pushing John\n\n";
     stack1.push("John");
//     cout << "Pushing Eli\n";
    // stack1.push('E');
    // cout << "Pushing Hope\n";
    // stack1.push('H');
// Pop the character values off the stack.
cout << "Popping...\n";
stack1.pop(catchStackVar1);
cout << catchStackVar1<< endl<< endl;
stack1.pop(catchStackVar1);
cout << catchStackVar1<< endl<< endl;
stack1.pop(catchStackVar1);
cout << catchStackVar1<< endl<< endl;
/*stack1.pop(catchStackVar1);
cout << catchStackVar1<< endl;
stack1.pop(catchStackVar1);
cout << catchStackVar1 << endl;
*/

cout<< setw(20) << "Pushing 22\n\n";
stack.push(22);
cout<< setw(20) << "Pushing 10\n\n";
stack.push(10);
cout<< setw(20) << "Pushing 18\n\n";
stack.push(18);
// Pop the values off the stack and dispaly them.

cout << "Popping...\n";
stack.pop(catchVar);
cout << catchVar << endl<< endl;
stack.pop(catchVar);
cout << catchVar << endl<< endl;
stack.pop(catchVar);
cout << catchVar << endl<< endl;
// Pop another value off the stack.

cout << "\nAttempting to pop again\n\n";
stack.pop(catchVar);

return 0;
}
