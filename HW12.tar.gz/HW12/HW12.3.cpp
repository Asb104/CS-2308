#include<iostream>
#include<stack>
#include<string>
using namespace std;
// Function to check whether open and close brackets are same type or different
bool CheckSameBrackets(char open,char close)
{
   if(open == '(' && close == ')') return true;
   else if(open == '{' && close == '}') return true;
   else if(open == '[' && close == ']') return true;
   return false;
}
bool checkexpr(string exp)
{
   stack<char> S;
   for(int i =0;i<exp.length();i++)
   {
       if(exp[i] == '(' || exp[i] == '{' || exp[i] == '[')
           S.push(exp[i]); // pushing the opening brackets on the stack
       
       else if (exp[i] == ' ')
	       return true; 
	       
       else if(exp[i] == ')' || exp[i] == '}' || exp[i] == ']')
       {
           if(S.empty() || !CheckSameBrackets(S.top(),exp[i]))
               return false;
	  
	   else
               S.pop(); // popping the brackets from the stack.
       }
       
   	     
   
   }
   return S.empty() ? true:false;
   }

int main()
{
   /*main code to test the brackets in an expression */
   string expression;
   cout<<"Enter an expression: "; // taking input from the user.
   cin>>expression;
   if(checkexpr(expression))
       cout<<"String is Balanced.\n";
   else
       cout<<"String is not Balanced.\n";
return 0;
}


